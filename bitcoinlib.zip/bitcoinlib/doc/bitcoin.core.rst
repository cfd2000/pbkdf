bitcoin.core
============

Everything consensus critical is found in the core subpackage.

:mod:`core`
-----------

.. automodule:: bitcoin.core

:mod:`key`
----------

.. automodule:: bitcoin.core.key

:mod:`script`
-------------

.. automodule:: bitcoin.core.script

:mod:`scripteval`
-----------------

.. automodule:: bitcoin.core.scripteval

:mod:`serialize`
----------------

.. automodule:: bitcoin.core.serialize

